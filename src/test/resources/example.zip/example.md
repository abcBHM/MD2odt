# Markdown

Images:

![img](img.png)
![img](img.jpg)
![img](img.gif)
![img](img.bmp)

Inside folder:

![img](folder/img.png)
